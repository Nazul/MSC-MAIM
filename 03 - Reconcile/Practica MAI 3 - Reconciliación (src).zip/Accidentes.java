
public class Accidentes {

	private String nombreCalle, colonia, ISOnombreCalle, accidentes;
	
	public Accidentes (String nombreCalle, String colonia, String accidentes)
	{
		this.nombreCalle = nombreCalle;
		this.colonia = colonia;
		this.accidentes = accidentes;
		this.ISOnombreCalle = "Pending"; 
	}
	
	String getNombreCalle()
	{
		return nombreCalle;
	}
	
	void setISONombreCalle(String ISONCalle)
	{
		ISOnombreCalle = ISONCalle;
	}
	
	public String toString()
	{
		String str;
		str = nombreCalle + "," + ISOnombreCalle  + "," +   colonia  + "," + accidentes;		
		return str;

	}
}
