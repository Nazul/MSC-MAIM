
public class MasterDataCalles {

	private String id, isoNombreCalle;
	
	public MasterDataCalles  (String id, String isoNombreCalle) {
		this.id = id;
		this.isoNombreCalle = isoNombreCalle;
	}
	
	public String getIsoNombreCalle()
	{
	  return isoNombreCalle;
	}
	
	
}
