import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Reconcilia {
	
	
	 public static void main(String[] args) {
		 
		 // 1.- read the accidents data
		 ArrayList<Accidentes> accidentes = new ArrayList<Accidentes>();

			
		 try {
			 BufferedReader br = new BufferedReader(new FileReader(new File("callesData.csv")));
			 String line;
			 // The header
			 line = br.readLine();
			while ((line = br.readLine()) != null) {
				

			     String[] entries = line.split(",", -1);

			     Accidentes accidente = new Accidentes(entries[0], entries[1], entries[2]);

			     accidentes.add(accidente);
			 }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Datos de accidentes cargados");
		
		 ArrayList<MasterDataCalles> mdCalles = new ArrayList<MasterDataCalles>();

			
		 try {
			 BufferedReader br = new BufferedReader(new FileReader(new File("MasterDataCalles.csv")));
			 String line;
			 // The header
			 line = br.readLine();
			while ((line = br.readLine()) != null) {
				

			     String[] entries = line.split(",", -1);

			     MasterDataCalles mdCalle = new MasterDataCalles(entries[0], entries[1]);

			     mdCalles.add(mdCalle);
			 }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Master data de calles cargada");
		 
	 }
	 
	 
}
